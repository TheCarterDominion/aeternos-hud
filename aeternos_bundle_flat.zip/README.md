
# Aeternos Hub (2025) — Deploy Anywhere

This folder contains:
- `index.html` — JS experience (canvas runner, audio, gamepad lab). Requires HTTPS for full features on iPad Safari.
- `nojs.html` — CSS-only fallback that works even if JavaScript is blocked.
- `manifest.webmanifest` + `sw.js` — PWA support (Add to Home Screen, offline).
- `icons/` — app icons.

## One‑Tap Deploy — GitHub Pages
1. Create a repo (public is fine), name: `aeternos-hub`.
2. Upload all files/folders from this bundle to the repo root.
3. Settings → Pages → Source: `main` → `/root`. Save.
4. Open the Pages URL (https://<yourname>.github.io/aeternos-hub/).  
5. On iPad Safari: tap **Enable Audio** once; then **Add to Home Screen** for PWA.

## Quick Deploy — Replit
1. New Repl → "Static (HTML, CSS, JS)".
2. Upload these files.
3. Press Run. Use the provided HTTPS URL.

## Notes (iPad/Safari)
- Audio and Gamepad require **HTTPS** and a **user gesture** to start.
- If you ever see a viewer with a **Done** button, that's a preview. Open the page in a normal Safari tab.
- For controller input, pair via Bluetooth; some managed profiles may restrict it.

— Aeternos, 2025
